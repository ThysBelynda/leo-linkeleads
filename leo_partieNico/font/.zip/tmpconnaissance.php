<?php
	session_start();
	if(isset($_SESSION['id']))
	{
		try
		{
			$bdd = new PDO('mysql:host=localhost;dbname=linkeleads;charset=utf8', 'root', 'CcaA!ra0130puCE');
		}
		catch (Exception $e)
		{
			die('Erreur : ' .$e->getMessage());
		}

		$requete = $bdd->prepare('UPDATE membres SET comment_connu_leo = :connaissanceLeo WHERE id = :id');
		$requete->execute(array(
			'connaissanceLeo' => $_POST['reponseUser'],
			'id' => $_SESSION['id']
		));

	}

	header('Location: prospecter.php');
?>
