<?php
	session_start();
	if(isset($_SESSION['id']))
	{
		try
		{
			$bdd = new PDO('mysql:host=localhost;dbname=linkeleads;charset=utf8', 'root', 'CcaA!ra0130puCE');
		}
		catch (Exception $e)
		{
			die('Erreur : ' .$e->getMessage());
		}

		$requete = $bdd->prepare('UPDATE membres SET message = :messageEnregistre WHERE id = :id');
		$requete->execute(array(
			'messageEnregistre' => $_POST['messageEnregistre'],
			'id' => $_SESSION['id']
		));

	}

	header('Location: message.php');
?>
