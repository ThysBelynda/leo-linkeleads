<footer>

	<div id="questions"><p id="txtQuestions">Vous avez des questions ?<br/>leo@linkeleads.com</p></div>

	<p id="centerFoot">Leo est un assistant commercial virtuel developpé avec professionnalisme par la société Linkeleads</p>

	<div id="socialNetwork">
		<img src="img/linkedin.png" id="linkedin" alt="linkedin" />
	</div>
</footer>
